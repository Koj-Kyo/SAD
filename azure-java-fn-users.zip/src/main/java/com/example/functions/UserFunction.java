package com.example.functions;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.*;
import com.microsoft.azure.functions.annotation.*;

import java.util.*;

public class UserFunction {
    private static final String DATABASE_NAME = "userdb";
    private static final String CONTAINER_NAME = "users";
    private static final ObjectMapper mapper = new ObjectMapper();

    private CosmosClient cosmosClient = new CosmosClientBuilder()
        .endpoint(System.getenv("COSMOS_ENDPOINT"))
        .key(System.getenv("COSMOS_KEY"))
        .consistencyLevel(ConsistencyLevel.EVENTUAL)
        .buildClient();

    private CosmosContainer container = cosmosClient
        .getDatabase(DATABASE_NAME)
        .getContainer(CONTAINER_NAME);

    @FunctionName("addUser")
    public HttpResponseMessage addUser(
        @HttpTrigger(name = "req", methods = {HttpMethod.POST}, authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<String>> request,
        final ExecutionContext context) {

        try {
            User user = mapper.readValue(request.getBody().orElseThrow(), User.class);
            user.setId(UUID.randomUUID().toString());
            container.createItem(user);
            return request.createResponseBuilder(HttpStatus.CREATED).body("User added").build();
        } catch (Exception e) {
            return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body("Error: " + e.getMessage()).build();
        }
    }

    @FunctionName("getUsers")
    public HttpResponseMessage getUsers(
        @HttpTrigger(name = "req", methods = {HttpMethod.GET}, authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<String>> request,
        final ExecutionContext context) {

        try {
            String query = "SELECT * FROM users";
            CosmosPagedIterable<User> users = container.queryItems(query, new CosmosQueryRequestOptions(), User.class);
            return request.createResponseBuilder(HttpStatus.OK).body(users.stream().toList()).build();
        } catch (Exception e) {
            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: " + e.getMessage()).build();
        }
    }
}