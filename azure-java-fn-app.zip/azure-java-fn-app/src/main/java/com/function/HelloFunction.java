
package com.function;

import com.microsoft.azure.functions.annotation.*;
import com.microsoft.azure.functions.*;

import com.azure.cosmos.*;
import com.azure.cosmos.models.*;

import java.util.*;

public class HelloFunction {
    @FunctionName("hello")
    public HttpResponseMessage run(
        @HttpTrigger(name = "req", methods = {HttpMethod.GET, HttpMethod.POST}, authLevel = AuthorizationLevel.ANONYMOUS)
        HttpRequestMessage<Optional<String>> request,
        final ExecutionContext context
    ) {
        String name = request.getQueryParameters().get("name");
        if (name == null) {
            name = request.getBody().orElse("Azure Java User");
        }

        try {
            CosmosClient client = new CosmosClientBuilder()
                .endpoint(System.getenv("COSMOS_ENDPOINT"))
                .key(System.getenv("COSMOS_KEY"))
                .consistencyLevel(ConsistencyLevel.EVENTUAL)
                .buildClient();

            CosmosContainer container = client
                .getDatabase("MyDatabase")
                .getContainer("MyContainer");

            Map<String, String> item = new HashMap<>();
            item.put("id", UUID.randomUUID().toString());
            item.put("name", name);

            container.createItem(item);
        } catch (Exception e) {
            context.getLogger().warning("Error saving to Cosmos DB: " + e.getMessage());
        }

        return request.createResponseBuilder(HttpStatus.OK)
                .body("Hello " + name + ", data saved!")
                .build();
    }
}
