package com.example.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import java.util.Map;
import java.util.HashMap;

public class CreateUserHandler implements RequestHandler<Map<String, Object>, Map<String, Object>> {
    public Map<String, Object> handleRequest(Map<String, Object> input, Context context) {
        Map<String, Object> response = new HashMap<>();

        // Basic JSON validation
        if (!input.containsKey("userId") || !input.containsKey("name") || !input.containsKey("email")) {
            throw new RuntimeException("Invalid JSON payload: 'userId', 'name', and 'email' are required.");
        }

        response.put("message", "User created with validation and Cognito protection!");
        response.put("user", input);
        return response;
    }
}