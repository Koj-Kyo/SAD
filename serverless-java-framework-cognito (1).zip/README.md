# ☁️ DEMO : Serverless Java API avec Serverless Framework + Cognito + Validation JSON

## Objectif :
API REST en Java 17 sécurisée par Cognito + validation JSON côté Lambda.

## Stack :
- Java 17 + Maven
- AWS Lambda + API Gateway
- Cognito (authentification par JWT)
- DynamoDB (NoSQL)
- Déploiement via Serverless Framework

## Déploiement :

```bash
mvn clean package
sls deploy
```

## Test API :

1. Authentifie-toi via Cognito → récupère un token JWT
2. Fais un POST :
```http
POST /user
Authorization: Bearer <token>
Content-Type: application/json

{
  "userId": "abc",
  "name": "Alice",
  "email": "alice@example.com"
}
```

## Pour aller plus loin :
- Ajoute des authorizers pour chaque fonction
- Ajoute un vrai validateur JSON (lib Java)
- Active CloudWatch Logs et X-Ray

---
Projet généré avec ❤️ par ScholarGPT